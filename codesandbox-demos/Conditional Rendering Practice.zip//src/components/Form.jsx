import React from "react";
import Input from "./Input";

function Form(props) {
  return (
    <form className="form">
      {/* <input type="text" placeholder="Username" /> */}
      <Input type="text" placeholder="Username" />
      {/* <input type="password" placeholder="Password" /> */}
      <Input type="password" placeholder="Password" />
      {/* <input type="password" placeholder="Confirm Password" /> */}
      {props.userIsRegistered && (
        <Input type="password" placeholder="Confirm Password" />
      )}
      <button type="submit">
        {props.userIsRegistered ? "Login" : "Register"}
      </button>
      {/* <button type="submit">Register</button> */}
    </form>
  );
}

export default Form;
