import React from "react";

function Footer() {
  return (
    <div>
      <footer>
        <p>Copyright ⓒ 2024</p>
      </footer>
    </div>
  );
}

export default Footer;
