import React from "react";
import ReactDOM from "react-dom";
import Heading from "./Header.jsx";
import Notes1 from "./Note.jsx";
import Footer from "./Footer.jsx";

function App() {
  return (
    <div>
      <h1 className="tobedeleted">
        <marquee>Keeper App Project Part-1 Solution</marquee>
      </h1>
      <Heading />
      <Notes1 />
      <Footer />
    </div>
  );
}

export default App;
