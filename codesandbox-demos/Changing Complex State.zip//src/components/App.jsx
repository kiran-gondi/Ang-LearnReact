import React, { useState } from "react";

function App() {
  // Stateful Constant
  // const [fName, setFName] = useState("");
  // const [lName, setLName] = useState("");
  const [fullName, setFullName] = useState({
    fName: "",
    lName: "",
  });

  // function updateFName(event) {
  //   const firstName = event.target.value;
  //   setFName(firstName);
  // }

  // function updateLName(event) {
  //   const lastName = event.target.value;
  //   setLName(lastName);
  // }

  function handleChange(event) {
    // const newValue = event.target.value;
    // const inputName = event.target.name;

    // Using destructuring in JS
    const { value, name } = event.target;

    // console.log(newValue);
    // console.log(inputName);
    setFullName((prevValue) => {
      // console.log(prevValue);
      if (name === "fName") {
        return { fName: value, lName: prevValue.lName };
      } else if (name === "lName") {
        return { fName: prevValue.fName, lName: value };
      }
    });
  }

  return (
    <div className="container">
      <h2>
        <marquee>Changing Complex State</marquee>
      </h2>
      <h1>
        Hello {fullName.fName} {fullName.lName}
      </h1>
      <form>
        <input
          name="fName"
          onChange={handleChange}
          placeholder="First Name"
          value={fullName.fName}
        />
        <input
          name="lName"
          onChange={handleChange}
          placeholder="Last Name"
          value={fullName.lName}
        />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
