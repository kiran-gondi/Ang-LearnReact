import React, { useState } from "react";

function App() {
  setInterval(fetchCurrentTime, 7000);

  let timeNow = new Date().toLocaleTimeString("it-IT");
  const [currTime, setTime] = useState(timeNow);

  function fetchCurrentTime() {
    const newTime = new Date().toLocaleTimeString("it-IT");
    setTime(newTime);
  }

  return (
    <div className="container">
      <h2>
        <marquee>useState Hooks Practice</marquee>
      </h2>
      <h1>{currTime}</h1>
      <button onClick={fetchCurrentTime}>Get Time</button>
    </div>
  );
}

export default App;
