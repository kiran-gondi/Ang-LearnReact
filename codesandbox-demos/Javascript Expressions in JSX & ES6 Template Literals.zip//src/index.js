import React from "react";
import ReactDOM from "react-dom";

const name = "Rommie";
const fName = "Roy";
const lName = "Smith";

const luckyNumber = 45;

ReactDOM.render(
  <div>
    <h1>Hello {name}!</h1>
    <h1>Hello {fName + " " + lName}!</h1>
    //ES6 Literal
    <h1>Hello {`${fName} ${lName}`}!</h1>
    <p>
      Your luck number is <b>{Math.floor(Math.random() * luckyNumber)}</b>
    </p>
  </div>,
  document.getElementById("root")
);
