import React from "react";
import ReactDOM from "react-dom";
//import pi, { doublePi, triplePi } from "./math.js";
//Other Way
import * as pi from "./math.js";

console.log(pi);

ReactDOM.render(
  <div>
    <h1>JS ES6 - Import, Export and Modules</h1>
    <ul>
      <li>{pi.default}</li>
      <li>{pi.doublePi()}</li>
      <li>{pi.triplePi()}</li>
    </ul>
  </div>,
  document.getElementById("root")
);
