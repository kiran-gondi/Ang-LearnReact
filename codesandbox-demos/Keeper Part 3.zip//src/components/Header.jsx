import React from "react";

function Header() {
  return (
    <header>
      <h2>
        <marquee>Keeper Part 3</marquee>
      </h2>
      <h1>Keeper</h1>
    </header>
  );
}

export default Header;
