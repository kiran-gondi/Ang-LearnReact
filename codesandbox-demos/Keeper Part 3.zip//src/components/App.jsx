import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import CreateArea from "./CreateArea";

function App() {
  //- Add new note to an array.
  const [notes, setNotes] = useState([]);

  function addNote(newNote) {
    // console.log(note);
    //- Add new note to an array.
    setNotes((prevNotes) => {
      return [...prevNotes, newNote];
    });
  }

  //- Callback from the Note component to trigger a delete function.
  function deleteNote(id) {
    //console.log("Delete note");
    setNotes((prevNotes) => {
      //- Use the filter function to filter out the item that needs deletion.
      return prevNotes.filter((noteItem, index) => {
        return index !== id;
      });
    });
  }

  return (
    <div>
      <Header />
      <CreateArea onAdd={addNote} />
      {/* -- Take array and render seperate Note components for each item. */}
      {notes.map((noteItem, index) => {
        return (
          <Note
            key={index}
            //- Pass a id over to the Note component, pass it back to the App when deleting.
            id={index}
            title={noteItem.title}
            content={noteItem.content}
            onDelete={deleteNote}
          />
        );
      })}
      <Footer />
    </div>
  );
}

export default App;
