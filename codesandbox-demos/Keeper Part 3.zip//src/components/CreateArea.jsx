import React, { useState } from "react";

function CreateArea(props) {
  //- Create a constant that keeps track of the title and content.
  const [note, setNote] = useState({
    title: "",
    content: "",
  });

  function handleChange(event) {
    const { name, value } = event.target;
    console.log(name, value);
    setNote((prevNote) => {
      return {
        ...prevNote,
        [name]: value,
      };
    });
  }

  function submitNote(event) {
    //- Pass the new note back to the App.
    props.onAdd(note);
    setNote({
      title: "",
      content: "",
    });
    event.preventDefault(); //Avoided to prevent the page refresh
  }

  return (
    <div>
      <form>
        <input
          name="title"
          onChange={handleChange}
          value={note.title}
          placeholder="Title"
        />
        <textarea
          name="content"
          onChange={handleChange}
          value={note.content}
          placeholder="Take a note..."
          rows="3"
        />
        {/* Pass the new note back to the App. */}
        <button onClick={submitNote}>Add</button>
      </form>
    </div>
  );
}

export default CreateArea;
