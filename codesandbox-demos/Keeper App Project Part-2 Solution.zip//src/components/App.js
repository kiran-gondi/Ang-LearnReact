import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import notes from "../notes";

//console.log(notes);

function createNote(note) {
  return (
    <Note
      key={note.key}
      id={note.key}
      title={note.title}
      content={note.content}
    />
  );
}
function App() {
  return (
    <div>
      <h1 className="tobedeleted">
        <marquee>Keeper App Project Part-2 Solution</marquee>
      </h1>
      <Header />
      {/* <Note /> */}
      {notes.map(createNote)}
      <Footer />
    </div>
  );
}

export default App;
