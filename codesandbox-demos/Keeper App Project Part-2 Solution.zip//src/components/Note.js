import React from "react";
import notes from "../notes";

function Note(prop) {
  return (
    <div className="note">
      <h1>
        {prop.id}. {prop.title}
      </h1>
      <p>{prop.content}</p>
    </div>
  );
}

export default Note;
