import React from "react";

function Avatar(props1) {
  return <img className="circle-img" src={props1.img} alt="avatar_img" />;
}

export default Avatar;
