import React from "react";

function CustomDetail(props1) {
  return <p className="info">{props1.customDetail}</p>;
}

export default CustomDetail;
