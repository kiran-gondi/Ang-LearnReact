import React from "react";
import Avatar from "./Avatar";
import CustomDetail from "./CustomDetail";

function Card(props1) {
  return (
    <div className="card">
      <div className="top">
        <h2 className="name">{props1.name}</h2>
        <Avatar img={props1.img} />
      </div>
      <div className="bottom">
        <CustomDetail customDetail={props1.tel} />
        <CustomDetail customDetail={props1.email} />
      </div>
    </div>
  );
}
export default Card;
