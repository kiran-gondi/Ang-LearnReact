import React from "react";
import Login from "./Login";

var isLoggedIn = false;

const currentTime = new Date().getHours();
console.log(currentTime);

function renderConditionally() {
  if (isLoggedIn === true) {
    return <h1>Hello</h1>;
  } else {
    return <Login />;
}

function App() {
  return (
    <div className="container">
      <h2>
        <marquee className="cust-marq">
          React conditional Rendering with the Ternary Opeator & AND Operator
        </marquee>
      </h2>
      {/* <h1>Hello</h1>
      <Login /> */}
      {/* {renderConditionally()} */}
      {isLoggedIn ? <h1>Hello</h1> : <Login />}
      {/* {currentTime > 12 ? <h1>Why are you still Working?</h1> : null} */}
      {/* {currentTime > 12 && <h1>Why are you still Working?</h1>} */}
    </div>
  );
}

export default App;
