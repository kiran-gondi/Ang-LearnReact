import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";

/*ReactDOM.render(
  <div>
    <Heading />
    <List />
  </div>
  <App />,
  document.getElementById("root")
);*/

ReactDOM.render(<App />, document.getElementById("root"));
