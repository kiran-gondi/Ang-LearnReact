import React from "react";

function Card(props1) {
  return (
    <div className="card">
      <div className="top">
        <h2 className="name">{props1.name}</h2>
        <img className="circle-img" src={props1.img} alt="avatar_img" />
      </div>
      <div className="bottom">
        <p>{props1.tel}</p>
        <p>{props1.email}</p>
      </div>
    </div>
  );
}
export default Card;
