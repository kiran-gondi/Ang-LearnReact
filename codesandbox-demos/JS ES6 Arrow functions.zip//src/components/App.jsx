import React from "react";
import Entry from "./Entry";
import emojipedia from "../emojipedia";

function App() {
  return (
    <div>
      <h2>
        <marquee class="marq">JS ES6 Arrow functions</marquee>
      </h2>
      <h1>
        <span>emojipedia</span>
      </h1>
      <dl className="dictionary">
        {/* Arrow Function */}
        {emojipedia.map((emojiTerm) => (
          <Entry
            key={emojiTerm.id}
            emoji={emojiTerm.emoji}
            name={emojiTerm.name}
            description={emojiTerm.meaning}
          />
        ))}
      </dl>
    </div>
  );
}

export default App;
