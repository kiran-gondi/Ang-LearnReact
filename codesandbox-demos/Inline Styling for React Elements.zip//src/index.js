import React from "react";
import ReactDOM from "react-dom";

const customStyle = {
  color: "red",
  fontSize: "20px",
  border: "1px solid black",
};

//customStyle.color = "pink";

ReactDOM.render(
  <div>
    <h1>Inline Styling for React Elements</h1>
    <h3 style={customStyle}>Hello World with inline style</h3>
  </div>,
  document.getElementById("root")
);
