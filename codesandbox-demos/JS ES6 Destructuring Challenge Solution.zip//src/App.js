import React from "react";

function App(props) {
  return (
    <div>
      <h2>
        <marquee>JS ES6 Destructuring Challenge Solution</marquee>
      </h2>
      <table>
        <tr>
          {/* <th>Brand</th> */}
          <th>Top Speed</th>
        </tr>
        <tr>
          {/* <td>{tesla.model}</td> */}
          <td>{props.teslaTopSpeed}</td>
          <td>{props.teslaTopColour}</td>
        </tr>
        <tr>
          {/* <td>{honda.model}</td> */}
          <td>{props.hondaTopSpeed}</td>
          <td>{props.hondaTopColour}</td>
        </tr>
      </table>
    </div>
  );
}

export default App;
