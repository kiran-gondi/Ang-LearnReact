// import animals, { useAnimals } from "./data";
// console.log(animals);

// const [cat, dog] = animals;

// console.log(useAnimals(cat));

// const [animal, makeSound] = useAnimals(cat);
// console.log(animal);
// //console.log(makeSound());
// makeSound();

// console.log(cat);
// console.log(dog);

// const { name, sound } = cat;
// console.log(name);
// console.log(sound);

// const { name: catName, sound: catSound } = cat;
// console.log(catName);
// console.log(catSound);

// const { name = "fluffy", sound = "durr" } = cat;
// console.log(name);
// console.log(sound);

// const {
//   name,
//   sound,
//   feedingRequirements: { food, water },
// } = cat;
// // console.log(name);
// // console.log(feedingRequirements);
// console.log(food);
// console.log(water);

// CHALLENGE: uncomment the code below and see the car stats rendered
import React from "react";
import ReactDOM from "react-dom";
import cars from "./practice";
import App from "./App";

console.log(cars);
const [honda, tesla] = cars;

const {
  speedStats: { topSpeed: hondaTopSpeed },
} = honda;

const {
  speedStats: { topSpeed: teslaTopSpeed },
} = tesla;

const {
  coloursByPopularity: [hondaTopColour],
} = honda;

const {
  coloursByPopularity: [teslaTopColour],
} = tesla;

console.log(hondaTopSpeed);

ReactDOM.render(
  <App
    teslaTopSpeed={teslaTopSpeed}
    teslaTopColour={teslaTopColour}
    hondaTopSpeed={hondaTopSpeed}
    hondaTopColour={hondaTopColour}
  />,
  document.getElementById("root")
);
