import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(
  <div>
    <h1>Hello React</h1>
    <p>Hello Paragraph 1233</p>
  </div>,
  document.getElementById("root")
);

var h1 = document.createElement("h1");
h1.innerHTML = "Hello Bob";
document.getElementById("root").appendChild(h1);
