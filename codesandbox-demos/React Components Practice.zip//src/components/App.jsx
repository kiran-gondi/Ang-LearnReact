import React from "react";
import Heading from "./Heading";

function App() {
  return (
    <div>
      <h1>React Components Practice</h1>
      <Heading />
    </div>
  );
}

export default App;
